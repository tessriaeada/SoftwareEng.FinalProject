Used vehicle listings: compact project extract

Source archive: usedcarsdataset.zip (vehicles.csv)
Rows retained: all source rows. The compact extract keeps structured fields relevant to vehicle pricing and coarse geography.

Removed fields: listing URLs and IDs, VIN, free-text descriptions and titles, exact street/city/postal address, coordinates, image URLs and counts, dealer payment and delivery attributes, and miscellaneous attributes.

Important: the source is primarily US Craigslist listings, with a small number of Canadian records and some records with no country value. It is not a UK dataset. The target `price` is an advertised asking price, not a completed sale price. For comparable currency, the project model should use US records only.

Fields: price, year, manufacturer, model, condition, cylinders, fuel, odometer, title_status, transmission, drive, size, type, paint_color, seller_type, region, address_country, address_state, posting_date
